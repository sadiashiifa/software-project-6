<?php
include('connect.php');  // Include the database connection

// Handle Insert Message
if (isset($_POST['new_message'])) {
    $new_message = $_POST['new_message'];

    // Sanitize message input to prevent SQL injection
    $new_message = $conn->real_escape_string($new_message);

    // SQL query to insert the new message
    $sql = "INSERT INTO messages (message) VALUES ('$new_message')";

    // Execute the query
    if ($conn->query($sql) === TRUE) {
        echo 'Message inserted successfully!';
    } else {
        echo 'Error: ' . $conn->error;
    }
}

// Handle Update Message (AJAX Request)
if (isset($_POST['id']) && isset($_POST['message'])) {
    $id = $_POST['id'];
    $message = $_POST['message'];

    // Sanitize message input to prevent SQL injection
    $message = $conn->real_escape_string($message);

    // SQL query to update the message
    $sql = "UPDATE messages SET message = '$message' WHERE id = $id";

    // Execute the query
    if ($conn->query($sql) === TRUE) {
        echo 'success';
    } else {
        echo 'error';
    }
    exit();  // Exit after handling the update request
}

// Handle Delete Message
if (isset($_POST['delete_id'])) {
    $delete_id = $_POST['delete_id'];

    // SQL query to delete the message
    $sql = "DELETE FROM messages WHERE id = $delete_id";

    // Execute the query
    if ($conn->query($sql) === TRUE) {
        echo 'Message deleted successfully!';
    } else {
        echo 'Error: ' . $conn->error;
    }
}


// SQL query to retrieve all messages
$sql = "SELECT * FROM messages ORDER BY created_at DESC";
$result = $conn->query($sql);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>BLOGS</title>
    <link rel="stylesheet" href="styles.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
</head>
<body>

<header>
        <nav>
            <!-- Link to show messages -->
            <a href="http://localhost/lgsg/see.php" class="btns">Show Messages</a>
        </nav>
    </header>

    <div class="messages-container">
        <h2>BLOGS</h2>

        <!-- Insert New Message Form -->
        <form method="POST" action="" class="insert-form">
            <textarea name="new_message" placeholder="Enter your writings..." required></textarea><br>
            <button type="submit">Submit</button>
        </form>

        <?php if ($result->num_rows > 0): ?>
            <div class="messages-list">
                <?php while ($row = $result->fetch_assoc()): ?>
                    <div class="message" id="message-<?php echo $row['id']; ?>">
                        <p class="message-text" id="message-text-<?php echo $row['id']; ?>"><?php echo htmlspecialchars($row['message']); ?></p>
                        <small class="message-time"><?php echo $row['created_at']; ?></small>

                        <!-- Edit Button -->
                        <button class="edit-button" onclick="editMessage(<?php echo $row['id']; ?>)">Edit</button>
                        
                        <!-- Delete Button -->
                        <form method="POST" action="" style="display:inline;">
                            <input type="hidden" name="delete_id" value="<?php echo $row['id']; ?>">
                            <input type="submit" value="Delete" class="delete-button" onclick="return confirm('Are you sure you want to delete this message?');">
                        </form>
                    </div>

                    <!-- Edit Message Form (hidden initially) -->
                    <div class="edit-form" id="edit-form-<?php echo $row['id']; ?>" style="display: none;">
                        <textarea id="edit-message-<?php echo $row['id']; ?>"><?php echo htmlspecialchars($row['message']); ?></textarea><br>
                        <button onclick="updateMessage(<?php echo $row['id']; ?>)">Update</button>
                        <button onclick="cancelEdit(<?php echo $row['id']; ?>)">Cancel</button>
                    </div>
                <?php endwhile; ?>
            </div>
        <?php else: ?>
            <p>No messages found.</p>
        <?php endif; ?>
    </div>

    <script>
        // Show edit form when 'Edit' button is clicked
        function editMessage(id) {
            document.getElementById('message-text-' + id).style.display = 'none';
            document.getElementById('edit-form-' + id).style.display = 'block';
        }

        // Cancel the editing and revert to the original message
        function cancelEdit(id) {
            document.getElementById('edit-form-' + id).style.display = 'none';
            document.getElementById('message-text-' + id).style.display = 'block';
        }

        // Update message via AJAX
        function updateMessage(id) {
            var updatedMessage = document.getElementById('edit-message-' + id).value;

            // Send the updated message using AJAX
            $.ajax({
                url: '',  // The current page
                type: 'POST',
                data: { id: id, message: updatedMessage },
                success: function(response) {
                    // If update is successful, update the message on the page without reloading
                    if(response === 'success') {
                        document.getElementById('message-text-' + id).innerHTML = updatedMessage;
                        cancelEdit(id);
                    } else {
                        alert('Error updating message');
                    }
                }
            });
        }
    </script>
    <style>/* Add this to your existing CSS file */

header nav {
    text-align: center;  /* This will center the contents of the navigation (like the button) */
    margin-top: 20px;     /* Optional: Adds some space at the top */
}

.btns {
    display: inline-block;
    background-color: #4CAF50; /* Green background color */
    color: white; /* White text color */
    padding: 12px 25px; /* Vertical and horizontal padding */
    font-size: 16px;
    text-align: center;
    text-decoration: none; /* Remove underline from the link */
    border-radius: 8px; /* Rounded corners */
    border: 2px solid #4CAF50; /* Border color matching the background */
    transition: all 0.3s ease; /* Smooth transition effect */
    cursor: pointer;
    margin: 0 auto;  /* Horizontally center the button */
}

.btns:hover {
    background-color: #45a049; /* Darker green background on hover */
    border-color: #45a049; /* Darker border color on hover */
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2); /* Shadow effect on hover */
}

.btns:focus {
    outline: none; /* Remove default outline on focus */
}

.btns:active {
    background-color: #388e3c; /* Even darker green when button is clicked */
    border-color: #388e3c; /* Darker border when clicked */
    box-shadow: 0 2px 5px rgba(0, 0, 0, 0.2); /* Smaller shadow when clicked */
}
</style>
</body>
</html>

<?php
// Close the database connection
$conn->close();
?>
